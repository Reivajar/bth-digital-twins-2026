# Prompts to start from

Paste one of these into the AI chat, then paste your whole `index.html` under it. Change the words in [brackets]. Always end by asking for the complete file.

These prompts get you a first version. The interesting part starts when the result is wrong: write that down in your build log.

## Context to paste once at the start of every new chat

> I am an urban planning student, not a programmer. I am changing a web page that shows a 3D map of Helsingborg with MapLibre GL JS. The page loads its data from local JavaScript files that I must not change. The buildings are in a GeoJSON variable called BUILDINGS. Each building has these properties: id, height_m (number), height_source (text), floors (number or null), use (text), ground_m (number, ground elevation in metres above sea level, approximate), model_checked (year, a number), source (text). There is also WATER and PARKS. Keep the page working by double-clicking the file, with no server and no new libraries from the internet. Keep the panel section "What this does not show" and keep my comments. Return the complete file, not a fragment.

## Tuesday warm-up (everyone)

> Change the slider so it highlights buildings **lower** than the chosen height instead of taller. Update the text in the panel to match.

Then break it on purpose: ask for something vague, such as "make it look better", and see what happens. Go back to your saved copy.

## Option A. Sea level and buildings

> Replace the height function with a sea-level function. Add a slider for water level from 0 to 5 metres in steps of 0.25. Colour buildings whose ground_m is below the chosen level blue and all others light grey. Show the number of affected buildings in the Result section. Update the Function text to: "The tool shall show which buildings stand on ground below a user-selected water level."

Things to try next: count affected buildings by use; add a second level for a 100-year storm on top of the mean level.

What you will find: ground_m comes from a 30 m grid that partly includes rooftops. Look at which buildings it gets wrong. That is a Data finding for your brief.

## Option B. Where the model is out of date

> Replace the height function with a model-currency function. Colour buildings by model_checked: before 2015 dark red, 2015 to 2019 orange, 2020 or later green. Add a slider "Show buildings not checked since [year]" from 2010 to 2026. Show the number of buildings not checked since the chosen year. Update the Function text to: "The tool shall show which parts of the city model have not been checked against reality since a user-selected year."

Things to try next: show the share of out-of-date buildings by use; list the ten oldest.

What you will find: model_checked is invented. No public data says when Helsingborg's model was last updated for each building. Your brief has to say who would record it, and how.

## Option C. Massing sketch for dialogue

> Add a sketch tool. When I click "Start drawing", each click on the map adds a corner of a new building footprint, and "Finish" closes the shape. Add a number box for height in metres. Show the new building in 3D in a bright blue colour among the existing buildings. In the Result section, show the height of the tallest existing building within 50 metres of the new one, and the difference.

Things to try next: add several proposals and switch between them; show the floor count at 3 m per floor.

What you will find: many neighbour heights are estimated. Click them to see height_source. A height comparison is only as good as that field.

## Option D. Delivery access (only if the data is confirmed)

Javier will add a prompt and a data file if open loading-zone data for Helsingborg is confirmed. Until then, a group interested in logistics can propose it as its own function.

## Your own function

Write your one-sentence function first, starting with "The tool shall". Then:

> Replace the height function with this: [your sentence]. Use these fields: [fields from the list]. Keep everything else on the page.

If no field in the data supports your function, that is a finding. Ask the AI to create clearly labelled invented data, and declare it in the honesty box.
